import java.util.ArrayList;
import java.util.Collections;

public class Tower {

    private static final int PX_PER_CM = 20;
    private static final int CANVAS_W = 600;
    private static final int CANVAS_H = 600;

    private int width;
    private int maxHeight;
    private int towerX;
    private int towerY;
    private int currentTopY;

    private boolean visible;
    private boolean ok;

    private Rectangle leftSide;
    private Rectangle rightSide;
    private Rectangle base;
    private ArrayList<Rectangle> marks;
    
    private ArrayList<Cup> cups;
    private ArrayList<Lid> lids;
    private ArrayList<String[]> items;
    
    /**
     * @param width la anchura de la interfaz de la torre (0<width<27)
     * @param maxHeight altura de la interfaz de la torre y numero permitido de altura de la torre (0<maxHeight<29)
     */
    public Tower(int width, int maxHeight) {       
        this.width = width;
        this.maxHeight = maxHeight;
        
        visible = false;
        ok = true;
        
        marks = new ArrayList<>();
        cups = new ArrayList<>();
        lids = new ArrayList<>();
        items = new ArrayList<>();
        
        buildGraphics();
    }

    private void buildGraphics() {
        
        int widthPx = getTowerWidthPx();
        int heightPx = getTowerHeightPx();

        int markLength = 20;
        int markGap = 10;
        int extraLeft = markLength + markGap;
        
        int totalWidth = widthPx + extraLeft;

        towerX = (CANVAS_W - totalWidth) / 2 + extraLeft;
        towerY = (CANVAS_H - heightPx) / 2;
        currentTopY = towerY + getTowerHeightPx() - 4;

        leftSide = new Rectangle(towerX, towerY, heightPx, 4, "black");
        rightSide = new Rectangle(towerX + widthPx - 4, towerY, heightPx, 4, "black");
        base = new Rectangle(towerX, towerY + heightPx, 4, widthPx, "black");

        for (int cm = 0; cm <= maxHeight; cm++) {
            int y = towerY + heightPx - (cm * PX_PER_CM);
            int x = towerX - markGap - markLength;
            Rectangle mark = new Rectangle(x, y, 3, markLength, "black");
            marks.add(mark);
        }
    }
    
    public boolean ok() {
        return ok;
    }

    public void makeVisible() {

        visible = true;

        leftSide.makeVisible();
        rightSide.makeVisible();
        base.makeVisible();

        for (Rectangle r : marks) {
            r.makeVisible();
        }

        ok = true;
    }

    public void makeInvisible() {

        if (!visible) return;

        leftSide.makeInvisible();
        rightSide.makeInvisible();
        base.makeInvisible();

        for (Rectangle r : marks) {
            r.makeInvisible();
        }

        visible = false;
        ok = true;
    }

    public int getTowerX() {
        return towerX;
    }

    public int getTowerY() {
        return towerY;
    }

    public int getTowerWidthPx() {
        return width * PX_PER_CM;
    }

    public int getTowerHeightPx() {
        return maxHeight * PX_PER_CM;
    }
    
    public void pushCup(int number) {
        ok = true;

        if (number <= 0) { 
            fail("El numero debe ser mayor que 0."); 
            return; 
        }
        if (cupExists(number)) { 
            fail("Ya existe una taza con ese numero."); 
            return; 
        }
        if (heightWithCup(number) > maxHeight) { 
            fail("Se supera la altura maxima."); 
            return;
        }

        String color = pickColor(number);

        Cup top = topCup();
        boolean lastIsCup = !items.isEmpty() && items.get(items.size() - 1)[0].equals("cup");
        boolean goesInside = top != null && lastIsCup && number < top.getNumber();

        int baseY;

        if (items.isEmpty()) {
            baseY = towerY + getTowerHeightPx();
        } else if (goesInside) {
            baseY = top.getBaseY() - PX_PER_CM;   
        } else {
            baseY = currentTopY;                  
        }

        Cup cup = new Cup(number, color, towerX, getTowerWidthPx(), baseY);

        cups.add(cup);
        items.add(new String[] { "cup", String.valueOf(number) });
        
        if (items.isEmpty()) {
            currentTopY = baseY - cup.heightPx();
        } else if (goesInside) {
            currentTopY = currentTopY;   
        } else {
            currentTopY = baseY - cup.heightPx();              
        }

        if (visible) {
            cup.makeVisible();
        }
        
    
    }

    
    public void pushLid(int number) {
        ok = true;
        if (number <= 0) { 
            fail("El numero debe ser mayor que 0."); 
            return; 
        }
        if (lidExists(number)) { 
            fail("Ya existe una tapa para ese numero."); 
            return; 
        }
        if (heightWithLid() > maxHeight) { 
            fail("Se supera la altura maxima."); 
            return;
        }

        String color = pickColor(number);
        Cup top = topCup();
        boolean lastIsCup = !items.isEmpty() && items.get(items.size() - 1)[0].equals("cup");
        boolean goesInside = (top != null) && lastIsCup && (number < top.getNumber());
        int lidY;
        
        if (items.isEmpty()) {
            lidY = (towerY + getTowerHeightPx()) - PX_PER_CM;
            
        } else if (goesInside) {
            lidY = top.getBaseY() - (2 * PX_PER_CM);     
        } else {
            lidY = currentTopY - PX_PER_CM;
            
        }
        
        Lid lid = new Lid(number, color, towerX, getTowerWidthPx(), lidY);

        lids.add(lid);
        items.add(new String[]{"lid", String.valueOf(number)});

        if (visible) lid.makeVisible();
        
        currentTopY = lidY;
    }
    
    public void popCup() {
        ok = true;
        int idx = findTopIndexOf("cup");
        if (idx == -1) { 
            fail("No hay tazas en la torre."); 
            return;
        }

        int cupNum = Integer.parseInt(items.get(idx)[1]);
        if (idx + 1 < items.size() && items.get(idx + 1)[0].equals("lid") && Integer.parseInt(items.get(idx + 1)[1]) == cupNum) {
            items.remove(idx + 1);
        }   
        items.remove(idx);
        rebuildStack();
    }    
    

    public void popLid() {
        ok = true;
        int idx = findTopIndexOf("lid");
        if (idx == -1) { fail("No hay tapas en la torre."); 
            return; 
        }
        items.remove(idx);
        rebuildStack();
    }

    public void removeCup(int number) {
        ok = true;
        int idx = findIndexOf("cup", number);
        if (idx == -1) { 
            fail("No existe una taza con ese numero en la torre.");
            return; 
        }

        if (idx + 1 < items.size() && items.get(idx + 1)[0].equals("lid") && Integer.parseInt(items.get(idx + 1)[1]) == number) {
        items.remove(idx + 1);
        }
        items.remove(idx);

        rebuildStack();
    }

    public void removeLid(int number) {
        ok = true;
        int idx = findIndexOf("lid", number);
        if (idx == -1) { 
            fail("No existe una tapa con ese numero en la torre."); 
            return; 
        }
        items.remove(idx);
        rebuildStack();
    }


    private void fail(String message) { 
        ok = false; 
        if (visible) 
            javax.swing.JOptionPane.showMessageDialog(null, message); 
    }

    private boolean cupExists(int number) { 
        for (Cup c : cups) { 
            if (c.getNumber() == number) 
            return true; 
        } 
        return false; }
    
    private boolean lidExists(int number) { 
        for (Lid l : lids) { 
            if (l.getNumber() == number) 
            return true;
        } 
        return false; 
    }
    
    private int heightWithCup(int newNumber) {
        int baseNumber;
        if (cups.isEmpty()) {
            baseNumber = newNumber;
        } else {
            baseNumber = cups.get(0).getNumber();
        }
        int baseHeight = 2 * baseNumber - 1;
        int totalItems = items.size() + 1;
        return baseHeight + (totalItems - 1);
    }
    
    private int heightWithLid() { 
        if (cups.isEmpty()) return 0; 
        int baseNumber = cups.get(0).getNumber(); 
        int baseHeight = 2 * baseNumber - 1; 
        int totalItems = items.size() + 1; 
        return baseHeight + (totalItems - 1); 
    }

    
    private String pickColor(int number) { 
        String[] colors = {"red","blue","green","yellow","magenta","cyan","orange","pink"}; 
        return colors[number % colors.length]; 
    }
    
    private Cup topCup() {

        for (int i = items.size() - 1; i >= 0; i--) {

            String type = items.get(i)[0];

            if (type.equals("cup")) {

                int number = Integer.parseInt(items.get(i)[1]);

                for (int j = cups.size() - 1; j >= 0; j--) {

                    if (cups.get(j).getNumber() == number) {
                        return cups.get(j);
                    }
                }
            }
        }

        return null;
    }


    private void rebuildStack() {
        for (Cup c : cups) {
            c.makeInvisible();
        }
        for (Lid l : lids) {
            l.makeInvisible();
        }
        cups.clear();
        lids.clear();
        currentTopY = towerY + getTowerHeightPx();
        Cup topCup = null;
        for (int i = 0; i < items.size(); i++) {
            String type = items.get(i)[0];
            int number = Integer.parseInt(items.get(i)[1]);
            String color = pickColor(number);
            if (type.equals("cup")) {
                boolean lastIsCup = (i > 0) && items.get(i - 1)[0].equals("cup");
                boolean goesInside = topCup != null && lastIsCup && number < topCup.getNumber();
                int baseY;
                if (goesInside) {
                    baseY = topCup.getBaseY() - PX_PER_CM;   
                } else {
                    baseY = currentTopY;                     
                }
                Cup cup = new Cup(number, color, towerX, getTowerWidthPx(), baseY);
                cups.add(cup);
                if (visible) {
                    cup.makeVisible();
                }
                if (goesInside) {
                    currentTopY = currentTopY;   
                } else {
                    currentTopY = baseY - cup.heightPx();              
                }      
                topCup = cup;
            } else { 
                boolean lastIsCup = (i > 0) && items.get(i - 1)[0].equals("cup");
                boolean goesInside = (topCup != null) && lastIsCup && (number < topCup.getNumber());
                int lidY;
                if (goesInside) {
                    lidY = topCup.getBaseY() - (2 * PX_PER_CM);  
                } else {
                    lidY = currentTopY - PX_PER_CM;
                    currentTopY = lidY;
                }
                Lid lid = new Lid(number, color, towerX, getTowerWidthPx(), lidY);
                lids.add(lid);
                if (visible) {
                    lid.makeVisible();
                }
            }
        }
    }

    
    private int findTopIndexOf(String type) { 
        for (int i = items.size() - 1; i >= 0; i--) {
            if (items.get(i)[0].equals(type)) { 
                return i; 
            }
        }    
        return -1;    
    }
    
    private int findIndexOf(String type, int number) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i)[0].equals(type) && Integer.parseInt(items.get(i)[1]) == number) {
                return i; 
            }    
        }
        return -1;
    }
    
    public void orderTower(){
        
        ArrayList<Integer> cupsNumbers = new ArrayList<>();
        ArrayList<Integer> lidsNumbers = new ArrayList<>();
        
        for (Cup cup: cups){
            int number = cup.getNumber();
            cupsNumbers.add(number);
        }
        
        for (Lid lid: lids){
            int number = lid.getNumber();
            lidsNumbers.add(number);
        }
        
        Collections.sort(cupsNumbers, Collections.reverseOrder());
        Collections.sort(lidsNumbers, Collections.reverseOrder());
        
        items.clear();
        
        for (int number: cupsNumbers){
            
            items.add(new String[] { "cup", String.valueOf(number) });
            
            if (lidsNumbers.contains(number)){
                items.add(new String[] { "lid", String.valueOf(number) });
            }
        }
        
        rebuildStack();
        
        
    }
    
    public void reverseTower(){
        ArrayList<String[]> newOrder = new ArrayList<>();
        
        for (int i = items.size() - 1; i >= 0; i--){
            newOrder.add(items.get(i));
        }
        
        this.items = newOrder;
        
        rebuildStack();
    }
    
    
}