
public class Lid {

    private int number;
    private Rectangle top;
    private static final int PX_PER_CM = 20;

    public Lid(int number, String color, int towerX, int towerWidthPx, int lidY) {
        this.number = number;
        int lidHeightPx = PX_PER_CM;
        int lidWidthPx = number * PX_PER_CM * 2;
        int lidX = towerX + (towerWidthPx - lidWidthPx) / 2;
        top = new Rectangle(lidX, lidY, lidHeightPx, lidWidthPx, color);
    }

    public int getNumber() { 
        return number; 
    }

    public void makeVisible() { 
        top.makeVisible(); 
    }

    public void makeInvisible() {
        top.makeInvisible(); 
    }
}
