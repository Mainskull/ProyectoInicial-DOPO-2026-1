import java.util.ArrayList;

public class Cup {

    private int number;

    private Rectangle leftWall;
    private Rectangle rightWall;
    private Rectangle base;
    private int baseY;
    private static final int PX_PER_CM = 20;

    public Cup(int number, String color, int towerX, int towerWidthPx, int baseY) {

        this.number = number;

        int cupHeightPx = (2 * number - 1) * PX_PER_CM;
        int cupWidthPx  = number * PX_PER_CM * 2;
        this.baseY = baseY;
        int cupX = towerX + (towerWidthPx - cupWidthPx) / 2;
        int cupY = baseY - cupHeightPx;

        int wallThickness = 8;
        int baseThickness = PX_PER_CM;

        leftWall = new Rectangle(cupX, cupY, cupHeightPx - baseThickness, wallThickness, color);
        rightWall = new Rectangle(cupX + cupWidthPx - wallThickness, cupY, cupHeightPx - baseThickness, wallThickness, color);
        base = new Rectangle(cupX, cupY + cupHeightPx - baseThickness, baseThickness, cupWidthPx, color);
    }

    public int getNumber() {
        return number;
    }
    
    public int getBaseY() { 
        return baseY; 
    }
    public int heightPx() { 
        return (2 * number - 1) * PX_PER_CM; 
    }
    
    
    public int height() {
        return 2 * number - 1;
    }

    public void makeVisible() {
        leftWall.makeVisible();
        rightWall.makeVisible();
        base.makeVisible();
    }

    public void makeInvisible() {
        leftWall.makeInvisible();
        rightWall.makeInvisible();
        base.makeInvisible();
    }
}
